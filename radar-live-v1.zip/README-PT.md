# Radar Live v1
Primeira base do radar.

1. Instale Node.js 20+.
2. Copie `.env.example` para `.env`.
3. Coloque sua chave Sportradar em `SPORTRADAR_API_KEY`.
4. Rode `npm install` e depois `npm start`.
5. Abra `http://localhost:3000`.

A chave fica no servidor, nunca no HTML.

Esta versão já consulta o Live Timelines, detecta `goal` e `corner`, registra timestamps e mostra a latência do feed. Ainda NÃO consulta odds das casas; isso será adicionado por adaptadores autorizados.
