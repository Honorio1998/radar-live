import express from "express";
import { setTimeout as sleep } from "node:timers/promises";

const app = express();
const PORT = Number(process.env.PORT || 3000);
const POLL_MS = Number(process.env.POLL_MS || 1000);
const KEY = process.env.SPORTRADAR_API_KEY;
const LEVEL = process.env.ACCESS_LEVEL || "trial";
const LANG = process.env.LANGUAGE_CODE || "pt";
const clients = new Set();
const seen = new Set();
let state = {connected:false,lastPollAt:null,lastError:null,matches:[],events:[]};

app.use(express.static("public"));

function push(msg){
  const s=`data: ${JSON.stringify(msg)}\n\n`;
  for(const r of clients){try{r.write(s)}catch{}}
}
function addEvent(e){
  const k=`${e.matchId}:${e.eventId}:${e.sourceTime}`;
  if(seen.has(k)) return;
  seen.add(k);
  state.events.unshift(e); state.events=state.events.slice(0,100);
  push({type:"event",event:e});
}
function findMatches(data){
  const out=[];
  function walk(x){
    if(!x || typeof x!=="object") return;
    if(x.sport_event && Array.isArray(x.timeline)){out.push(x);return;}
    if(Array.isArray(x)) x.forEach(walk); else Object.values(x).forEach(walk);
  }
  walk(data); return out;
}
function normalize(m){
  const cs=m.sport_event?.competitors||[];
  return {
    matchId:m.sport_event?.id||null,
    home:cs.find(c=>c.qualifier==="home")?.name||"Casa",
    away:cs.find(c=>c.qualifier==="away")?.name||"Fora",
    status:m.sport_event_status?.status||"unknown",
    homeScore:m.sport_event_status?.home_score??null,
    awayScore:m.sport_event_status?.away_score??null,
    timelineCount:m.timeline?.length||0
  };
}
async function poll(){
  if(!KEY){state.lastError="Defina SPORTRADAR_API_KEY no servidor.";push({...state,type:"status"});return;}
  const url=`https://api.sportradar.com/soccer/${LEVEL}/v4/${LANG}/schedules/live/timelines.json`;
  try{
    const r=await fetch(url,{headers:{accept:"application/json","x-api-key":KEY}});
    const raw=await r.text();
    if(!r.ok) throw new Error(`Sportradar HTTP ${r.status}: ${raw.slice(0,250)}`);
    const data=JSON.parse(raw), matches=findMatches(data);
    state.connected=true; state.lastError=null; state.lastPollAt=new Date().toISOString();
    state.matches=matches.map(normalize);
    for(const m of matches) for(const e of (m.timeline||[])){
      if(!["goal","corner"].includes(e.description)) continue;
      addEvent({
        source:"Sportradar",matchId:m.sport_event?.id,eventId:String(e.id??""),
        eventType:e.description,timelineType:e.type,competitor:e.competitor,
        matchClock:e.match_clock,sourceTime:e.time||null,
        receivedAt:new Date().toISOString(),
        feedLagMs:e.time?Math.max(0,Date.now()-Date.parse(e.time)):null,
        homeScore:e.home_score??m.sport_event_status?.home_score??null,
        awayScore:e.away_score??m.sport_event_status?.away_score??null
      });
    }
    push({type:"status",...state});
  }catch(err){
    state.connected=false; state.lastError=err.message||String(err); push({type:"status",...state});
  }
}
app.get("/api/status",(_q,res)=>res.json(state));
app.get("/api/stream",(q,res)=>{
  res.setHeader("Content-Type","text/event-stream");res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");res.flushHeaders?.();clients.add(res);
  res.write(`data: ${JSON.stringify({type:"status",...state})}\n\n`);
  q.on("close",()=>clients.delete(res));
});
app.listen(PORT,()=>console.log(`Radar Live: http://localhost:${PORT}`));
(async()=>{while(true){await poll();await sleep(POLL_MS)}})();
